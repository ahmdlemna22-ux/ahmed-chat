$ErrorActionPreference = 'Stop'

Write-Host '=== Ahmed Chat APK Builder ===' -ForegroundColor Cyan
if (-not (Get-Command flutter -ErrorAction SilentlyContinue)) {
  throw 'Flutter غير مثبت أو غير مضاف إلى PATH. ثبّت Flutter SDK ثم أعد فتح PowerShell.'
}
if (-not (Get-Command java -ErrorAction SilentlyContinue)) {
  throw 'Java غير موجود. ثبّت Android Studio مع Android SDK.'
}

# Generate the missing Android platform folder while preserving the Dart source.
if (-not (Test-Path '.\android')) {
  flutter create --platforms=android --org com.ahmedchat .
  if ($LASTEXITCODE -ne 0) { throw 'فشل إنشاء ملفات Android.' }
}

# Set the requested Android application ID and namespace.
$gradleGroovy = '.\android\app\build.gradle'
$gradleKts = '.\android\app\build.gradle.kts'
if (Test-Path $gradleGroovy) {
  $g = Get-Content $gradleGroovy -Raw
  $g = $g -replace "applicationId\s+['\"]com\.ahmedchat[^'\"]*['\"]", "applicationId 'com.ahmedchat.app'"
  $g = $g -replace "namespace\s+['\"]com\.ahmedchat[^'\"]*['\"]", "namespace 'com.ahmedchat.app'"
  Set-Content $gradleGroovy $g
} elseif (Test-Path $gradleKts) {
  $g = Get-Content $gradleKts -Raw
  $g = $g -replace 'applicationId\s*=\s*"com\.ahmedchat[^"]*"', 'applicationId = "com.ahmedchat.app"'
  $g = $g -replace 'namespace\s*=\s*"com\.ahmedchat[^"]*"', 'namespace = "com.ahmedchat.app"'
  Set-Content $gradleKts $g
} else {
  throw 'لم يتم العثور على ملف إعداد Gradle الخاص بتطبيق Android.'
}

# Jitsi Meet Android SDK requires API 24 or newer.
if (Test-Path $gradleGroovy) {
  $g = Get-Content $gradleGroovy -Raw
  if ($g -match 'minSdkVersion\s+[^\r\n]+') { $g = $g -replace 'minSdkVersion\s+[^\r\n]+', 'minSdkVersion 24' }
  elseif ($g -match 'minSdk\s*=\s*\d+') { $g = $g -replace 'minSdk\s*=\s*\d+', 'minSdk = 24' }
  Set-Content $gradleGroovy $g
} elseif (Test-Path $gradleKts) {
  $g = Get-Content $gradleKts -Raw
  $g = $g -replace 'minSdk = flutter\.minSdkVersion', 'minSdk = 24'
  $g = $g -replace 'minSdk = \d+', 'minSdk = 24'
  Set-Content $gradleKts $g
}

# Add permissions and resolve the Jitsi application-label manifest conflict.
$manifest = '.\android\app\src\main\AndroidManifest.xml'
if (Test-Path $manifest) {
  $m = Get-Content $manifest -Raw
  if ($m -notmatch 'xmlns:tools=') { $m = $m -replace '<manifest([^>]*)>', '<manifest$1 xmlns:tools="http://schemas.android.com/tools">' }
  foreach ($permission in @('android.permission.CAMERA','android.permission.RECORD_AUDIO','android.permission.INTERNET','android.permission.MODIFY_AUDIO_SETTINGS')) {
    if ($m -notmatch [regex]::Escape($permission)) { $m = $m -replace '(<application)', ('<uses-permission android:name="' + $permission + '" />' + "`r`n    " + '$1') }
  }
  if ($m -notmatch 'tools:replace=') { $m = $m -replace '<application', '<application tools:replace="android:label"' }
  if ($m -notmatch 'android:label=') { $m = $m -replace '<application', '<application android:label="أحمد شات"' }
  Set-Content $manifest $m
}

# Copy the supplied Firebase configuration into the Android app folder.
if (-not (Test-Path '.\google-services.json')) {
  throw 'ملف google-services.json غير موجود في المجلد الرئيسي للمشروع.'
}
$firebaseConfig = Get-Content '.\google-services.json' -Raw | ConvertFrom-Json
if ($firebaseConfig.project_info.project_id -ne 'ahmed-chat-cb6a6' -or $firebaseConfig.client[0].client_info.android_client_info.package_name -ne 'com.ahmedchat.app') {
  throw 'ملف Firebase لا يطابق المشروع أو اسم الحزمة com.ahmedchat.app.'
}
Copy-Item '.\google-services.json' '.\android\app\google-services.json' -Force
if (-not (Test-Path '.\lib\firebase_options.dart')) {
  if (-not (Get-Command flutterfire -ErrorAction SilentlyContinue)) {
    dart pub global activate flutterfire_cli
    if ($LASTEXITCODE -ne 0) { throw 'تعذر تثبيت FlutterFire CLI.' }
  }
  flutterfire configure --project=ahmed-chat-cb6a6 --platforms=android
  if ($LASTEXITCODE -ne 0) { throw 'فشل إعداد Firebase. تحقق من تسجيل الدخول إلى Firebase CLI.' }
}

flutter pub get
if ($LASTEXITCODE -ne 0) { throw 'فشل تنزيل حزم Flutter.' }
flutter build apk --release
if ($LASTEXITCODE -ne 0) { throw 'فشل بناء APK. راجع رسالة الخطأ أعلاه.' }

$apk = '.\build\app\outputs\flutter-apk\app-release.apk'
if (Test-Path $apk) {
  Copy-Item $apk '.\AhmedChat.apk' -Force
  Write-Host 'تم إنشاء الملف: AhmedChat.apk' -ForegroundColor Green
} else {
  throw 'انتهى البناء لكن لم يتم العثور على ملف APK في المسار المتوقع.'
}
