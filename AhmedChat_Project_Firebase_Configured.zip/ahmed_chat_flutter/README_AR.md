# أحمد شات — مشروع Flutter مبدئي

هذا مشروع بداية لتطبيق Android عربي للمراسلة الخاصة بين الأصدقاء باستخدام Firebase.

## الموجود في هذه النسخة
- تسجيل حساب بالبريد الإلكتروني وكلمة المرور.
- حفظ اسم المستخدم والبريد في Firestore.
- البحث عن صديق بالبريد الإلكتروني وإنشاء محادثة ثنائية.
- رسائل نصية مباشرة عبر Cloud Firestore.
- اختيار صورة من الهاتف ورفعها إلى Firebase Storage.
- واجهة عربية باللون الأزرق والأبيض.

## ما لم يُفعّل بعد
- المكالمات الصوتية والمرئية: أزرار الواجهة موجودة فقط. يلزم دمج مزود اتصال مثل Jitsi أو Agora وإعداد مفاتيح الاتصال.
- إشعارات الرسائل، استعادة كلمة المرور، التحقق من البريد، الحظر والإبلاغ تحتاج إعداداً إضافياً.
- هذه نسخة MVP أولية وليست تطبيقاً منشوراً أو مختبراً على جهاز حقيقي.

## خطوات التجهيز على الكمبيوتر

### 1) تثبيت الأدوات
- ثبّت Flutter SDK: https://docs.flutter.dev/get-started/install
- ثبّت Android Studio مع Android SDK.
- افتح Terminal أو PowerShell ونفّذ `flutter doctor` واتبع ما يطلبه لإكمال إعداد Android.

### 2) فك الضغط وتهيئة Android
افتح نافذة Terminal داخل مجلد `ahmed_chat_flutter` ثم نفّذ:
```bash
flutter create --platforms=android --org com.ahmed .
```
سيُنشئ هذا ملفات Android الناقصة حول ملفات المشروع الحالية.

### 3) ربط Firebase
- في Firebase Console افتح المشروع `ahmed-chat-cb6a6`.
- من Project settings أضف تطبيق Android.
- استخدم معرّف الحزمة الذي أنشأه Flutter في `android/app/build.gradle` أو `build.gradle.kts` (غالباً `com.ahmed.ahmed_chat`).
- نزّل `google-services.json` وضعه في `android/app/`.
- ثبّت FlutterFire CLI:
```bash
dart pub global activate flutterfire_cli
```
- نفّذ:
```bash
flutterfire configure
```
واختر مشروع `ahmed-chat-cb6a6` ومنصة Android. سيُنشئ الأمر `lib/firebase_options.dart` الذي يستخدمه التطبيق.

### 4) إعداد Firebase Console
- Authentication > Sign-in method: فعّل Email/Password.
- Firestore Database: تأكد أن قاعدة البيانات التي أنشأتها موجودة.
- Storage: أنشئ Default bucket إذا لم يكن قد أُنشئ، واختر منطقة أوروبية متوافقة مع إعدادات مشروعك.
- انشر قواعد `firebase/firestore.rules` في Firestore > Rules.
- انشر قواعد `firebase/storage.rules` في Storage > Rules.

### 5) تشغيل التطبيق
من مجلد المشروع:
```bash
flutter pub get
flutter doctor
flutter run
```
وصّل هاتف Android بالكمبيوتر عبر USB، وفعّل Developer options وUSB debugging، ثم وافق على رسالة السماح على الهاتف. أو شغّل محاكي Android من Android Studio.

## تنبيهات أمان مهمة
- لا تنشر التطبيق للعامة قبل مراجعة قواعد Firestore وStorage واختبارها.
- قاعدة `users` في هذه النسخة تسمح للمستخدم المسجل بقراءة ملفات المستخدمين للبحث بالبريد؛ هذا قد يكشف البريد الإلكتروني. قبل الإطلاق العام استبدل البحث بدليل أسماء مستعارة محدود البيانات أو Cloud Function تتحقق من البريد دون كشف قائمة المستخدمين.
- لا تضع مفاتيح أسرار مزود المكالمات داخل التطبيق.
- لا تشارك `google-services.json` أو أي مفاتيح خاصة علناً.
