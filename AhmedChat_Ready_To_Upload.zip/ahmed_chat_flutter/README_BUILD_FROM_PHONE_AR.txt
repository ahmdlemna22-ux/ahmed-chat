بناء أحمد شات من الهاتف عبر GitHub (بدون PowerShell)

1) افتح https://github.com من الهاتف وسجّل الدخول أو أنشئ حساباً.
2) اضغط + ثم New repository.
3) اكتب الاسم AhmedChat ثم اختر Private ثم Create repository.
4) ارفع محتويات هذا المجلد إلى المستودع. يجب أن يكون pubspec.yaml وlib وgoogle-services.json في جذر المستودع، ومعهما المجلد .github.
   ملاحظة: عند الرفع من المتصفح قد لا يظهر المجلد المخفي .github. إذا لم يظهر، أنشئ ملفاً جديداً بهذا المسار بالضبط:
   .github/workflows/android-apk.yml
   وانسخ محتواه من النسخة المرفقة.
5) بعد اكتمال الرفع افتح تبويب Actions في المستودع.
6) اختر Build Ahmed Chat APK ثم Run workflow ثم الزر الأخضر Run workflow.
7) انتظر حتى تصبح النتيجة خضراء، افتح عملية البناء، وانزل إلى Artifacts واضغط AhmedChat-APK لتنزيل ZIP.
8) افتح ZIP في الهاتف واستخرج app-release.apk ثم ثبّته. قد تحتاج السماح بالتثبيت من هذا المصدر.

معرّف تطبيق Firebase المطلوب: com.ahmedchat.app
ملف google-services.json مرفق بالفعل ويجب أن يبقى في جذر المشروع؛ سير العمل ينسخه إلى android/app.

تنبيه: هذا يبني نسخة APK أولية. يجب تفعيل Email/Password في Firebase Authentication وإنشاء Firestore وStorage وضبط قواعد الأمان قبل الاستخدام الفعلي. ميزات المكالمات تحتاج اختباراً وإعداداً مستقلاً.
