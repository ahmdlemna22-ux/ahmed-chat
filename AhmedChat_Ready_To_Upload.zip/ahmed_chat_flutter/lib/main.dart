import 'dart:io';
import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:jitsi_meet_flutter_sdk/jitsi_meet_flutter_sdk.dart';
import 'dart:math';

const blue = Color(0xFF1769D2);
const paleBlue = Color(0xFFEAF2FF);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(); // Android configuration is read from google-services.json.
  runApp(const AhmedChatApp());
}

class AhmedChatApp extends StatelessWidget {
  const AhmedChatApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'أحمد شات',
    theme: ThemeData(
      colorScheme: ColorScheme.fromSeed(seedColor: blue),
      scaffoldBackgroundColor: Colors.white,
      useMaterial3: true,
      appBarTheme: const AppBarTheme(backgroundColor: Colors.white, foregroundColor: blue),
      inputDecorationTheme: InputDecorationTheme(
        filled: true, fillColor: paleBlue,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
      ),
    ),
    home: const AuthGate(),
  );
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});
  @override
  Widget build(BuildContext context) => StreamBuilder<User?>(
    stream: FirebaseAuth.instance.authStateChanges(),
    builder: (context, snap) {
      if (snap.connectionState == ConnectionState.waiting) {
        return const Scaffold(body: Center(child: CircularProgressIndicator()));
      }
      return snap.data == null ? const LoginPage() : const HomePage();
    },
  );
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final email = TextEditingController(), password = TextEditingController(), username = TextEditingController();
  bool register = false, busy = false;
  String error = '';
  Future<void> submit() async {
    setState(() { busy = true; error = ''; });
    try {
      final auth = FirebaseAuth.instance;
      if (register) {
        final cred = await auth.createUserWithEmailAndPassword(
          email: email.text.trim(), password: password.text,
        );
        await FirebaseFirestore.instance.collection('users').doc(cred.user!.uid).set({
          'uid': cred.user!.uid,
          'username': username.text.trim(),
          'email': email.text.trim().toLowerCase(),
          'createdAt': FieldValue.serverTimestamp(),
        });
      } else {
        await auth.signInWithEmailAndPassword(email: email.text.trim(), password: password.text);
      }
    } on FirebaseAuthException catch (e) {
      setState(() => error = e.message ?? 'تعذر تسجيل الدخول');
    } catch (_) {
      setState(() => error = 'حدث خطأ. تحقق من اتصالك وإعداد Firebase.');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }
  @override
  void dispose() { email.dispose(); password.dispose(); username.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => Directionality(textDirection: TextDirection.rtl, child: Scaffold(
    body: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(24), child: Column(
      crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        const Icon(Icons.chat_bubble_rounded, color: blue, size: 76),
        const SizedBox(height: 12),
        const Text('أحمد شات', textAlign: TextAlign.center, style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: blue)),
        const Text('مراسلتك الخاصة مع الأصدقاء', textAlign: TextAlign.center),
        const SizedBox(height: 28),
        if (register) ...[
          TextField(controller: username, decoration: const InputDecoration(labelText: 'اسم المستخدم')),
          const SizedBox(height: 12),
        ],
        TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'البريد الإلكتروني')),
        const SizedBox(height: 12),
        TextField(controller: password, obscureText: true, decoration: const InputDecoration(labelText: 'كلمة المرور')),
        if (error.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 12), child: Text(error, style: const TextStyle(color: Colors.red))),
        const SizedBox(height: 18),
        FilledButton(onPressed: busy ? null : submit, child: Text(busy ? 'يرجى الانتظار...' : register ? 'إنشاء حساب' : 'تسجيل الدخول')),
        TextButton(onPressed: () => setState(() { register = !register; error = ''; }),
          child: Text(register ? 'لديك حساب؟ تسجيل الدخول' : 'مستخدم جديد؟ إنشاء حساب')),
      ],
    ))),
  ));
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});
  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser!;
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: const Color(0xFFF7F9FE),
        appBar: AppBar(
          elevation: 0,
          backgroundColor: Colors.white,
          titleSpacing: 18,
          title: Row(children: [
            Container(width: 42, height: 42,
              decoration: BoxDecoration(color: blue, borderRadius: BorderRadius.circular(14)),
              child: const Icon(Icons.forum_rounded, color: Colors.white, size: 24)),
            const SizedBox(width: 10),
            const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('أحمد شات', style: TextStyle(color: Color(0xFF172B4D), fontWeight: FontWeight.w800, fontSize: 19)),
              Text('دردش مع أصدقائك', style: TextStyle(color: Colors.blueGrey, fontSize: 11)),
            ]),
          ]),
          actions: [
            IconButton(tooltip: 'تسجيل الخروج', onPressed: () async => FirebaseAuth.instance.signOut(),
              icon: const Icon(Icons.logout_rounded, color: blue)),
            const SizedBox(width: 5),
          ],
        ),
        body: Column(children: [
          Container(
            width: double.infinity,
            margin: const EdgeInsets.fromLTRB(16, 14, 16, 12),
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Color(0xFF1769D2), Color(0xFF4598F5)], begin: Alignment.topRight, end: Alignment.bottomLeft),
              borderRadius: BorderRadius.circular(22),
              boxShadow: [BoxShadow(color: blue.withOpacity(.18), blurRadius: 16, offset: const Offset(0, 7))],
            ),
            child: Row(children: [
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('أهلاً بك 👋', style: TextStyle(color: Colors.white70, fontSize: 14)),
                const SizedBox(height: 5),
                Text(user.email ?? 'صديقنا العزيز', maxLines: 1, overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 17)),
                const SizedBox(height: 8),
                const Text('ابقَ قريباً من الأشخاص الذين تحبهم', style: TextStyle(color: Colors.white, fontSize: 12)),
              ])),
              Container(width: 58, height: 58, decoration: BoxDecoration(color: Colors.white.withOpacity(.18), shape: BoxShape.circle),
                child: const Icon(Icons.chat_bubble_rounded, color: Colors.white, size: 30)),
            ]),
          ),
          Padding(padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 4),
            child: Row(children: [
              const Expanded(child: Text('محادثاتك', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w800, color: Color(0xFF172B4D)))),
              TextButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AddFriendPage())),
                icon: const Icon(Icons.person_add_alt_1_rounded, size: 18), label: const Text('صديق جديد')),
            ])),
          Expanded(child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
            stream: FirebaseFirestore.instance.collection('chats')
              .where('members', arrayContains: user.uid).orderBy('updatedAt', descending: true).snapshots(),
            builder: (context, snap) {
              if (snap.hasError) return const Center(child: Padding(padding: EdgeInsets.all(24), child: Text('تعذر تحميل المحادثات. تحقق من إعدادات Firestore.')));
              if (!snap.hasData) return const Center(child: CircularProgressIndicator(color: blue));
              final docs = snap.data!.docs;
              if (docs.isEmpty) return Center(child: Padding(padding: const EdgeInsets.all(28), child: Column(mainAxisSize: MainAxisSize.min, children: [
                Container(width: 104, height: 104, decoration: const BoxDecoration(color: paleBlue, shape: BoxShape.circle),
                  child: const Icon(Icons.forum_outlined, size: 48, color: blue)),
                const SizedBox(height: 18),
                const Text('لا توجد محادثات بعد', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF172B4D))),
                const SizedBox(height: 7),
                const Text('أضف صديقاً وابدأ أول محادثة بينكما', textAlign: TextAlign.center, style: TextStyle(color: Colors.blueGrey)),
                const SizedBox(height: 18),
                FilledButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AddFriendPage())),
                  icon: const Icon(Icons.person_add), label: const Text('إضافة صديق')),
              ])));
              return ListView.separated(
                padding: const EdgeInsets.fromLTRB(14, 4, 14, 90), itemCount: docs.length,
                separatorBuilder: (_, __) => const SizedBox(height: 8),
                itemBuilder: (context, i) {
                  final d = docs[i]; final data = d.data();
                  final title = (data['title'] ?? 'محادثة خاصة').toString();
                  return Material(color: Colors.white, borderRadius: BorderRadius.circular(17), child: ListTile(
                    contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
                    leading: const CircleAvatar(radius: 26, backgroundColor: paleBlue,
                      child: Icon(Icons.person_rounded, color: blue, size: 29)),
                    title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF172B4D))),
                    subtitle: Text((data['lastMessage'] ?? 'ابدأ المحادثة الآن').toString(), maxLines: 1, overflow: TextOverflow.ellipsis),
                    trailing: const Icon(Icons.arrow_back_ios_new_rounded, size: 16, color: Colors.blueGrey),
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ChatPage(chatId: d.id, title: title))),
                  ));
                },
              );
            },
          )),
        ]),
        floatingActionButton: FloatingActionButton.extended(
          backgroundColor: blue, foregroundColor: Colors.white,
          onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AddFriendPage())),
          icon: const Icon(Icons.edit_rounded), label: const Text('محادثة جديدة', style: TextStyle(fontWeight: FontWeight.bold)),
        ),
      ),
    );
  }
}

class AddFriendPage extends StatefulWidget {
  const AddFriendPage({super.key});
  @override
  State<AddFriendPage> createState() => _AddFriendPageState();
}
class _AddFriendPageState extends State<AddFriendPage> {
  final email = TextEditingController();
  String status = ''; bool busy = false;
  Future<void> add() async {
    setState(() { busy = true; status = ''; });
    try {
      final me = FirebaseAuth.instance.currentUser!;
      final found = await FirebaseFirestore.instance.collection('users')
        .where('email', isEqualTo: email.text.trim().toLowerCase()).limit(1).get();
      if (found.docs.isEmpty) { setState(() => status = 'لم نجد حساباً بهذا البريد.'); return; }
      final friend = found.docs.first;
      if (friend.id == me.uid) { setState(() => status = 'لا يمكنك إضافة نفسك.'); return; }
      final ids = [me.uid, friend.id]..sort();
      final chatId = ids.join('_');
      await FirebaseFirestore.instance.collection('chats').doc(chatId).set({
        'members': ids, 'title': friend.data()['username'] ?? 'صديق',
        'lastMessage': '', 'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));
      if (mounted) Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => ChatPage(chatId: chatId, title: friend.data()['username'] ?? 'صديق')));
    } catch (_) { setState(() => status = 'تعذر إنشاء المحادثة. تحقق من قواعد Firestore.'); }
    finally { if (mounted) setState(() => busy = false); }
  }
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('إضافة صديق')),
    body: Padding(padding: const EdgeInsets.all(20), child: Column(children: [
      TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'البريد الإلكتروني للصديق')),
      const SizedBox(height: 16), FilledButton(onPressed: busy ? null : add, child: Text(busy ? 'جارٍ البحث...' : 'إنشاء محادثة')),
      if (status.isNotEmpty) Padding(padding: const EdgeInsets.all(12), child: Text(status)),
      const SizedBox(height: 8),
      const Text('يجب أن يكون الصديق قد أنشأ حساباً في أحمد شات أولاً.', textAlign: TextAlign.center),
    ])),
  );
}

class ChatPage extends StatefulWidget {
  final String chatId, title;
  const ChatPage({super.key, required this.chatId, required this.title});
  @override
  State<ChatPage> createState() => _ChatPageState();
}
class _ChatPageState extends State<ChatPage> {
  final text = TextEditingController();
  bool sending = false;
  StreamSubscription<QuerySnapshot<Map<String, dynamic>>>? incomingCalls;
  final Set<String> handledCalls = {};

  @override
  void initState() {
    super.initState();
    _watchIncomingCalls();
  }

  void _watchIncomingCalls() {
    final uid = FirebaseAuth.instance.currentUser!.uid;
    incomingCalls = FirebaseFirestore.instance.collection('chats').doc(widget.chatId)
      .collection('calls').where('to', isEqualTo: uid)
      .snapshots().listen((snapshot) {
        for (final call in snapshot.docs) {
          if (call.data()['status'] != 'ringing') continue;
          if (!handledCalls.add(call.id) || !mounted) continue;
          _showIncomingCall(call.reference, call.data());
        }
      });
  }

  Future<void> _showIncomingCall(DocumentReference<Map<String, dynamic>> ref, Map<String, dynamic> data) async {
    if (!mounted) return;
    final audioOnly = data['audioOnly'] == true;
    final accept = await showDialog<bool>(context: context, barrierDismissible: false, builder: (ctx) => AlertDialog(
      title: Text(audioOnly ? 'مكالمة صوتية واردة' : 'مكالمة فيديو واردة'),
      content: const Text('صديقك يتصل بك عبر أحمد شات.'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('رفض')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('قبول')),
      ],
    ));
    if (accept == true && mounted) {
      await ref.update({'status': 'accepted'});
      await _joinCall((data['room'] ?? '').toString(), audioOnly);
    } else {
      await ref.update({'status': 'declined'});
    }
  }

  String _randomRoomSuffix() {
    const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
    final random = Random.secure();
    return List.generate(28, (_) => chars[random.nextInt(chars.length)]).join();
  }

  Future<void> _startCall({required bool audioOnly}) async {
    try {
      final uid = FirebaseAuth.instance.currentUser!.uid;
      final chat = await FirebaseFirestore.instance.collection('chats').doc(widget.chatId).get();
      final members = List<String>.from(chat.data()?['members'] ?? []);
      final other = members.firstWhere((id) => id != uid);
      final ref = FirebaseFirestore.instance.collection('chats').doc(widget.chatId).collection('calls').doc();
      final room = 'ahmedchat_${ref.id}_${_randomRoomSuffix()}';
      await ref.set({'from': uid, 'to': other, 'room': room, 'audioOnly': audioOnly,
        'status': 'ringing', 'createdAt': FieldValue.serverTimestamp()});
      await _joinCall(room, audioOnly);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر بدء المكالمة: $e')));
    }
  }

  Future<void> _joinCall(String room, bool audioOnly) async {
    if (room.isEmpty) return;
    final user = FirebaseAuth.instance.currentUser!;
    final profile = await FirebaseFirestore.instance.collection('users').doc(user.uid).get();
    final displayName = (profile.data()?['username'] ?? user.email ?? 'مستخدم أحمد شات').toString();
    final options = JitsiMeetConferenceOptions(
      serverURL: 'https://meet.jit.si', room: room,
      configOverrides: {'startWithAudioMuted': false, 'startWithVideoMuted': audioOnly,
        'subject': audioOnly ? 'مكالمة صوتية - أحمد شات' : 'مكالمة فيديو - أحمد شات'},
      featureFlags: {'unsaferoomwarning.enabled': false},
      userInfo: JitsiMeetUserInfo(displayName: displayName, email: user.email ?? ''),
    );
    JitsiMeet().join(options);
  }
  CollectionReference<Map<String, dynamic>> get messages =>
    FirebaseFirestore.instance.collection('chats').doc(widget.chatId).collection('messages');

  Future<void> send({String? imageUrl}) async {
    final value = text.text.trim();
    if (value.isEmpty && imageUrl == null) return;
    setState(() => sending = true);
    try {
      final uid = FirebaseAuth.instance.currentUser!.uid;
      await messages.add({
        'senderId': uid, 'text': value, 'imageUrl': imageUrl,
        'createdAt': FieldValue.serverTimestamp(),
      });
      await FirebaseFirestore.instance.collection('chats').doc(widget.chatId).update({
        'lastMessage': imageUrl == null ? value : 'صورة',
        'updatedAt': FieldValue.serverTimestamp(),
      });
      text.clear();
    } finally { if (mounted) setState(() => sending = false); }
  }

  Future<void> pickImage() async {
    final picked = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 80);
    if (picked == null) return;
    final uid = FirebaseAuth.instance.currentUser!.uid;
    final ref = FirebaseStorage.instance.ref('chat_images/${widget.chatId}/${DateTime.now().millisecondsSinceEpoch}_$uid.jpg');
    final task = await ref.putFile(File(picked.path));
    await send(imageUrl: await task.ref.getDownloadURL());
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(widget.title), actions: [
      IconButton(tooltip: 'مكالمة صوتية', onPressed: () => _startCall(audioOnly: true), icon: const Icon(Icons.call)),
      IconButton(tooltip: 'مكالمة فيديو', onPressed: () => _startCall(audioOnly: false), icon: const Icon(Icons.videocam)),
    ]),
    body: Column(children: [
      Expanded(child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: messages.orderBy('createdAt').snapshots(),
        builder: (context, snap) {
          if (snap.hasError) return const Center(child: Text('تعذر تحميل الرسائل.'));
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final docs = snap.data!.docs;
          return ListView.builder(padding: const EdgeInsets.all(12), itemCount: docs.length, itemBuilder: (context, i) {
            final m = docs[i].data(), mine = m['senderId'] == FirebaseAuth.instance.currentUser!.uid;
            final image = m['imageUrl'] as String?;
            return Align(alignment: mine ? Alignment.centerRight : Alignment.centerLeft, child: Container(
              constraints: const BoxConstraints(maxWidth: 280), margin: const EdgeInsets.symmetric(vertical: 5),
              padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: mine ? paleBlue : const Color(0xFFF2F2F2), borderRadius: BorderRadius.circular(14)),
              child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                if (image != null) Image.network(image, width: 220, fit: BoxFit.cover),
                if ((m['text'] ?? '').toString().isNotEmpty) Text(m['text']),
              ]),
            ));
          });
        },
      )),
      SafeArea(child: Padding(padding: const EdgeInsets.fromLTRB(8, 6, 8, 8), child: Row(children: [
        IconButton(onPressed: pickImage, icon: const Icon(Icons.image, color: blue)),
        Expanded(child: TextField(controller: text, textInputAction: TextInputAction.send, onSubmitted: (_) => send(), decoration: const InputDecoration(hintText: 'اكتب رسالة...'))),
        IconButton(onPressed: sending ? null : () => send(), icon: const Icon(Icons.send, color: blue)),
      ]))),
    ]),
  );
  @override
  void dispose() { incomingCalls?.cancel(); text.dispose(); super.dispose(); }
}
